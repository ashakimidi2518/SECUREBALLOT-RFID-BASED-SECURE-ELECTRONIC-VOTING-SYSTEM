Startup.o: Startup.s
