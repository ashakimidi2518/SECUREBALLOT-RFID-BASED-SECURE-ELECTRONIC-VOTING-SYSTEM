data.o: DATA.c
data.o: i2c_eeprom.h
data.o: types.h
data.o: data_location_defines.h
data.o: i2c_eeprom_defines.h
