//i2c_eeprom_defines.h


#define I2C_EEPROM_SA1	0X50

#define I2C_EEPROM_SA2	0X51

#define I2C_EEPROM_SA3	0X52

#define I2C_EEPROM_SA4	0X53

#define I2C_EEPROM_SA5	0X54

#define I2C_EEPROM_SA6	0X55

#define I2C_EEPROM_SA7	0X56

#define I2C_EEPROM_SA8	0X57
