kpm.o: KPM.c
kpm.o: kpm_defines.h
kpm.o: delay.h
kpm.o: types.h
kpm.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
kpm.o: types.h
kpm.o: lcd.h
kpm.o: types.h
