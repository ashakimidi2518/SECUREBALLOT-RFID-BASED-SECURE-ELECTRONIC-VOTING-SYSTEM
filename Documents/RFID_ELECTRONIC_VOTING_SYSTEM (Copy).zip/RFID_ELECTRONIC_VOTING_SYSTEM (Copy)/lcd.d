lcd.o: lcd.c
lcd.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
lcd.o: types.h
lcd.o: lcd_defines.h
lcd.o: defines.h
lcd.o: delay.h
lcd.o: types.h
