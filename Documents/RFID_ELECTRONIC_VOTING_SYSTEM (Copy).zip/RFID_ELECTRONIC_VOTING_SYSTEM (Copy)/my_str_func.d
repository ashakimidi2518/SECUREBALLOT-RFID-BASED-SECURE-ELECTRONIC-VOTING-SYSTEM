my_str_func.o: My_Str_Func.c
my_str_func.o: types.h
