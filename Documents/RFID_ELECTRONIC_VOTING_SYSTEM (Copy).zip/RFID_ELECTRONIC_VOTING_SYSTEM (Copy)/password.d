password.o: Password.c
password.o: types.h
password.o: lcd.h
password.o: types.h
password.o: lcd_defines.h
password.o: kpm.h
password.o: delay.h
password.o: types.h
