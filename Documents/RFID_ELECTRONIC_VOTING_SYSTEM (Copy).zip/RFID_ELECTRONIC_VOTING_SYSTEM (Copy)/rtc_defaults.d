rtc_defaults.o: RTC_Defaults.c
rtc_defaults.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
rtc_defaults.o: rtc_defines.h
rtc_defaults.o: lcd.h
rtc_defaults.o: types.h
