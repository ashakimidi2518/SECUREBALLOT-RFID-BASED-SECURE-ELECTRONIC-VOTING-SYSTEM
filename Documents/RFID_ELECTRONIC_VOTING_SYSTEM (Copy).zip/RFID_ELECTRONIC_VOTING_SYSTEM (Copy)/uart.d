uart.o: UART.c
uart.o: types.h
uart.o: uart_defines.h
uart.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
