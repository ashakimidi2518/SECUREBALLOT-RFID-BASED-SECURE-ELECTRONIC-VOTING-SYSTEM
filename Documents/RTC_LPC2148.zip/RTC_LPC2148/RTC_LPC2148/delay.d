.\delay.o: delay.c
