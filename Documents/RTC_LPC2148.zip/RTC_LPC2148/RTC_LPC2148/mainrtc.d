.\mainrtc.o: mainrtc.c
.\mainrtc.o: C:\Keil4_arm\ARM\Inc\Philips\LPC214x.h
.\mainrtc.o: uart0.h
.\mainrtc.o: delay.h
