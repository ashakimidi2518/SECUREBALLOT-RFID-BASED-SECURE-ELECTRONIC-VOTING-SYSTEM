.\uart0.o: uart0.c
.\uart0.o: C:\Keil4_arm\ARM\Inc\Philips\LPC214x.H
