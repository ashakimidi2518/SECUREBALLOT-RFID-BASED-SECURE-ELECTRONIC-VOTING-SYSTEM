# SecureBallot: RFID-Based Secure Electronic Voting System

A secure, tamper-evident electronic voting **prototype** built on the NXP LPC2148 (ARM7TDMI-S) using Embedded C and Keil µVision.

A voter is authenticated using an RFID card and a 4-digit PIN, can vote only once, and has the vote counted in non-volatile I²C EEPROM. An election officer card opens the administration menu. The on-chip RTC timestamps events, and an audit log is sent to a PC over UART without recording which party a voter selected.

> **Prototype notice:** This is an educational demonstration, not a certified or production-ready election system. Review the limitations below before using it beyond a lab demonstration.

## Table of contents

1. [Features](#features)
2. [System block diagram](#system-block-diagram)
3. [Hardware setup](#hardware-setup)
4. [Hardware and software](#hardware-and-software)
5. [Pin mapping](#pin-mapping)
6. [How the system works](#how-the-system-works)
7. [EEPROM memory map](#eeprom-memory-map)
8. [Audit log format](#audit-log-format)
9. [Build and flash](#build-and-flash)
10. [Demo walkthrough](#demo-walkthrough)
11. [Known limitations and future work](#known-limitations-and-future-work)
12. [Skills demonstrated](#skills-demonstrated)

## Features

- **Two-factor voter authentication:** RFID card (“something you have”) plus a 4-digit PIN (“something you know”); PIN entry is masked on the LCD.
- **One voter, one vote:** An EEPROM voter record stores a `voted` flag to block duplicate voting.
- **Ballot secrecy by design:** EEPROM stores each voter's voted flag and aggregate party totals. The audit event `VOTE_CAST` does not record the selected party.
- **RTC-based voting window:** Voter cards are rejected outside the configured voting period.
- **Officer console:** Supports time editing, result viewing, voter-card management, election reset, and officer-password changes.
- **Interrupt-driven RFID reception:** UART1 interrupt code parses the reader's 10-byte frame (`STX` + 8 ASCII digits + `ETX`).
- **PC audit log:** UART0 sends date, time, event, card ID, status, and description.
- **LCD party symbols:** Party symbols are drawn using LCD CGRAM custom characters.
- **Modular drivers:** LCD, keypad, UART0/UART1, I²C, EEPROM, and RTC drivers can be tested independently.

## System block diagram

The LPC2148 is the central controller. The 4×4 keypad and RFID reader provide inputs; the LCD, LEDs, and buzzer provide user feedback. The RTC supplies timestamps, the AT24C256 EEPROM stores voter flags and vote totals, and UART0 sends the audit log to a PC through a MAX232 interface.

![SecureBallot system block diagram showing LPC2148, keypad, RFID, RTC, LCD, LEDs, buzzer, EEPROM and PC serial connection](assets/secureballot-block-diagram.png)

**Main data flow:** RFID card tap → UART1 receive interrupt → main-loop authentication and RTC checks → keypad PIN → party selection and confirmation → EEPROM update → UART0 audit log.

## Hardware setup

The project is demonstrated on a Vector India Advanced Development Board for ARM7 using an LPC2148 controller. The RFID reader is connected with jumper wires, and the PC terminal displays the serial audit log.

![SecureBallot hardware setup on an ARM7 development board, with RFID reader wiring and serial audit log on the PC](assets/secureballot-hardware-setup.jpg)

## Hardware and software

### Hardware

- LPC2148 ARM7 development board
- RFID reader and RFID cards (8-digit ID; 10-byte serial frame)
- 20×4 LCD
- 4×4 matrix keypad
- Green/red LEDs and buzzer
- AT24C256 I²C EEPROM
- MAX232 interface and PC serial connection (DB9 or USB-to-UART converter)
- Jumper wires

### Software and tools

- Embedded C
- Keil µVision
- Flash Magic (ISP programming)
- HyperTerminal or another serial terminal

## Pin mapping

| Function | LPC2148 pin(s) | Notes |
|---|---|---|
| LCD data D0–D7 | P1.24–P1.31 | 8-bit mode |
| LCD RS / EN | P0.16 / P0.17 | RW tied to GND |
| Keypad rows (outputs) | P1.16–P1.19 | Driven low one at a time |
| Keypad columns (inputs) | P1.20–P1.23 | Pull-ups; read for key press |
| UART0 TxD0 / RxD0 | P0.0 / P0.1 | PC audit log through MAX232; also ISP port |
| UART1 TxD1 / RxD1 | P0.8 / P0.9 | RFID reader DOUT connects to RxD1 |
| I²C0 SCL / SDA | P0.2 / P0.3 | AT24C256; 4.7 kΩ pull-ups |
| Buzzer | P0.14 | Also the ISP-entry pin |

**Clock and serial settings:** 12 MHz crystal; PLL ×5 gives CCLK 60 MHz and PCLK 15 MHz. UART is configured for 9600 baud; I²C is configured for 100 kHz.

## How the system works

### 1. Power-on sequence (`main.c`)

1. Initialise the keypad, LCD, I²C, UART0, UART1 (with interrupt), buzzer, and CGRAM party symbols.
2. Seed EEPROM data (officer, voters, and counters) and set the RTC.
3. Print the audit-log header and `SYSTEM_START` over UART0.
4. Show the project name on the LCD for two seconds.
5. Enter the main loop, display RTC date/time, and wait for a card.

### 2. RFID reception (UART1 interrupt)

1. The reader sends 10 bytes at 9600 baud: `0x02` + 8 ASCII digits + `0x03`. For card `12345678`, the frame is `02 31 32 33 34 35 36 37 38 03`.
2. The interrupt service routine (ISR) waits for `STX`, stores the 8 ID bytes, accepts the frame only when followed by `ETX`, adds a null terminator, and sets `Rfid_ready`.
3. The main loop processes the completed ID. The ISR only collects data; slower application logic runs in `main()`.

### 3. Voter flow

1. Scan a card; log `CARD_SCAN`.
2. If it is the officer card, open the officer menu.
3. If voting is inactive according to the RTC window, show `Voting Not Started`.
4. Search the eight voter records in EEPROM. If no match exists, show `Invalid Voter`, sound the buzzer, and log `AUTHENTICATION FAILED`.
5. If the voter was removed, show `Voter Removed`. If the voter has already voted, show `Already Voted` and log `DUPLICATE_VOTE, BLOCKED`.
6. Ask for the 4-digit PIN (masked), allowing two attempts. Log `PASSWORD_CHECK`; never log the PIN.
7. Show the voter menu: `1 Vote`, `2 Change PIN`, `3 Exit`.
8. Display the eight-party menu with CGRAM symbols, then ask the voter to confirm Yes/No.
9. On confirmation, increment the selected party's EEPROM counter, set the voter's `voted` flag, display `Vote Successful`, and log `VOTE_CAST` without the party choice.

### 4. Officer flow

1. Scan the officer card and check its PIN; log `OFFICER_LOGIN`.
2. Menu page 1: `1 Edit Time`, `2 View Result`, `3 Edit Voter Cards`, `4 Next`. Page 2: `5 Reset Election`, `6 Edit Password`, `7 Back`, `8 Exit`.
3. **Edit Time:** Set the RTC date/time and voting start/stop hour and minute, with validation.
4. **View Result:** Show each party's count and the winner or a tie; log `VIEW_RESULT` and close voting (`STOP_VOTING`).
5. **Edit Voter Cards:** Add or soft-delete voters, up to eight records.
6. **Reset Election:** Clear all voted flags and zero the party counters.

### 5. Voting window

The described implementation opens voting when the RTC hour and minute equal the configured start time and closes it at the stop time. Outside the voting window, voter cards are rejected; the officer card remains usable.

### 6. Keypad keys

| Key | Meaning |
|---|---|
| `0–9` | Digits / menu choice |
| `=` | Enter / confirm |
| `c` | Cancel |
| `+` | Backspace |

## EEPROM memory map

| Address | Size | Content |
|---|---:|---|
| `0x0000` | 9 bytes | Officer RFID ID (8 digits + null terminator) |
| `0x0010` | 4 bytes | Officer password |
| `0x0020` | 1 byte | Voting flag (reserved) |
| `0x0021` | 1 byte | Total voters |
| `0x0030` / `0x0040` | Reserved | Voting start / end time (reserved in the documented map) |
| `0x0050–0x006F` | 8 × 4 bytes | Party 1–8 vote counters (`u32`, little-endian) |
| `0x0100 + 20*n` | 20 bytes per record | Voter record `n`, up to 8 voters |

Each voter record contains: offset `+0x00` card ID (9 bytes), `+0x0A` PIN (4 bytes), `+0x0E` voted flag (0/1), and `+0x0F` status (1 = active, 0 = removed).

## Audit log format

The PC audit log uses the fields:

`DATE, TIME, EVENT, CARD_ID, STATUS, DESCRIPTION`

Example lines:

```text
03-10-2026, 02:35:59, SYSTEM_START, -, SUCCESS, System Initialized
14-07-2026, 09:01:12, CARD_SCAN, 12345678, RECEIVED, RFID detected
14-07-2026, 09:01:36, VOTE_CAST, 12345678, SUCCESS, Vote recorded
14-07-2026, 09:35:18, DUPLICATE_VOTE, 12345678, BLOCKED, already voted
```

Events include `SYSTEM_START`, `CARD_SCAN`, `AUTHENTICATION`, `PASSWORD_CHECK`, `VOTE_CAST`, `DUPLICATE_VOTE`, `OFFICER_LOGIN`, `VIEW_RESULT`, `RESET_ELECTION`, `START_VOTING`, and `STOP_VOTING`.

## Build and flash

1. Clone the project repository (replace the placeholder with your actual repository URL):
   ```bash
   git clone https://github.com/ashakimidi2518/<your-repo-name>.git
   ```
2. Open `project_files.uvproj` in Keil µVision and select the LPC2148 target.
3. Build with **F7**. The documented expected result is `0 Error(s), 0 Warning(s)` and a `major_project.hex` output.
4. Wire the board according to the block diagram and pin mapping. Connect UART0 to the PC.
5. In Flash Magic, select device LPC2148, the correct COM port, baud rate 9600 or higher, and 12 MHz oscillator. Select `major_project.hex`, enable **Erase blocks used by Hex**, and start programming.
6. Open HyperTerminal or another serial terminal at **9600 baud, 8 data bits, no parity, 1 stop bit (8-N-1)**, with flow control disabled.
7. Reset the board. The LCD should show the project name and then `Waiting For Card`; the terminal should print `SYSTEM_START`.

## Demo walkthrough

1. Tap a registered voter card, enter the PIN, select `1 Vote`, choose a party, and confirm.
2. Tap the same card again; the system should show `Already Voted`.
3. Tap an unregistered card; the system should show `Invalid Voter` and sound the buzzer.
4. Tap the officer card, enter the officer PIN, and use the menu to set time, view results, or reset the election.
5. Observe each action as a timestamped line in the serial terminal.

**Demo-data warning:** The project documentation says demo officer/voter records and default PINs are seeded in `DATA.c`. They are for demonstration only. Change them before any non-demo use, and do not publish real card IDs.

## Known limitations and future work

The project documentation identifies these limitations:

- EEPROM data is re-seeded on every power-up; add an initialisation marker so vote data persists across resets.
- Voting start/stop times are held in RAM; store them in EEPROM.
- The RTC is set at boot; use a 32.768 kHz crystal and VBAT backup, and initialise only when stopped.
- Vote updates are not atomic; write the voted flag first or use a commit record and CRC.
- A 32-byte voter-record stride would avoid 64-byte EEPROM page wrap-around.
- Add I²C status checks and time-outs, a watchdog, PIN lockout, and hashed PINs.
- Planned improvements include external-interrupt officer mode, LED indicators, per-session CSV logging on the PC, and stronger cards (MIFARE) or fingerprint authentication.

## Skills demonstrated

- Embedded C and LPC2148 register-level programming
- GPIO and UART with VIC interrupts
- I²C master driver and EEPROM data layout
- RTC integration
- HD44780 LCD and CGRAM custom characters
- Matrix keypad scanning
- State-based application design
- Serial audit logging
- Hardware/software integration and debugging

---

**Platform:** NXP LPC2148 · **IDE:** Keil µVision · **Programming:** Flash Magic · **Training board:** Vector India Advanced Development Board for ARM7
